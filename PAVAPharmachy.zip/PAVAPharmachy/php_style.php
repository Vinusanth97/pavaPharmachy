<!DOCTYPE html>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
</head>
<body>

</body>
</html>
<?php
$con=new mysqli('localhost','root','','webtech');
/*
if($con->connect_errno)
{
	echo $con->connect_error;
	die();
}
else
{
	echo "Database connected";
}
*/
if(isset($_POST['submit'])){

$fname=$_POST['fname'];
$lname=$_POST['lname'];
$email=$_POST['email'];
$pword=$_POST['pword'];
$confirm_pword=$_POST['confirm_pword'];
	if($fname!=''&&$lname!=''&&$email!=''&&$pword!=''&&$confirm_pword!=''){
	$sql="insert into customers(fname,lname,email,pword,confirm_pword) values('$fname','$lname','$email','$pword','$confirm_pword')";
	if($con->query($sql))
	{
		echo "data stored";
	}
	else
	{
		echo "Insert data Fail";
	}
		}
		else{
			echo "all filed required";

		}
}


else
{
	echo "Data not insert";
}






?>
