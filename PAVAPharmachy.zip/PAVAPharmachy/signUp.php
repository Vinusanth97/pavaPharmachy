<?php

include 'config.php';




if(isset($_POST['submit'])){

   $fname = mysqli_real_escape_string($link, $_POST['fname']);
   $lname = mysqli_real_escape_string($link, $_POST['lname']);
   $district = mysqli_real_escape_string($link, $_POST['district']);
   $address = mysqli_real_escape_string($link, $_POST['address']);
   $username = mysqli_real_escape_string($link, $_POST['username']);
   $email = mysqli_real_escape_string($link, $_POST['email']);
   $mobilenumber = mysqli_real_escape_string($link, $_POST['mobilenumber']);
   $password = mysqli_real_escape_string($link, $_POST['password']);
   $password2 = mysqli_real_escape_string($link, $_POST['password2']);

   $select = mysqli_query($link, "SELECT * FROM customers WHERE password = '$password' AND username='$username'AND email='$email'") or die('query failed');

   if(mysqli_num_rows($select) > 0){
    //  $message[] = 'user already exist!';
   }
   else if($password!=$password2){}
      else{
      mysqli_query($link, "INSERT INTO customers(fname, lname,district,address,username,email,mobilenumber, password,password2) VALUES('$fname', '$lname','$district','$address','$username','$email', '$mobilenumber','$password','$password2')") or die('query failed');
      //$message[] = 'registered successfully!';
    
     
      header('location:login.php');
   }

}

   
   
	
?>


<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="signUp_login_Style.css">
	<script src="https://kit.fontawesome.com/228b3df31e.js" crossorigin="anonymous"></script>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<title>Sign UP</title>
</head>
<body>
	
	<div class="container2">
		<h1>Sign Up</h1>
		<h4>It's free and only takes a minute</h4>
		<form action="" method="POST" class="form" id="form" autocomplete="off">
			<div class="form-control">
				<label>First Name</label>
				<input type="text" name="fname" placeholder="First Name" id="fname" onkeydown="checkInput()" required="" >
				<i class="icon1 fa-solid fa-circle-check"></i>
				<i class="icon2 fa-solid fa-circle-exclamation"></i>
				<small>Error Message</small>
			</div>
			<div class="form-control">
				<label>Last Name</label>
				<input type="text" name="lname" placeholder="Last Name" id="lname"  onkeydown="checkInput()" required="">
				<i class="icon1 fa-solid fa-circle-check"></i>
				<i class="icon2 fa-solid fa-circle-exclamation"></i>
				<small>Error Message</small>
			</div>
				<div class="form-control">
				<label>District</label>
				<select name="district">
				   <option value=""> Select Option</option>
				   <option value="Colombo"> Colombo</option>
				   <option value="Gampaha"> Gampaha</option>
				   <option value="Kalutara">Kalutara</option>
				   <option value="Kandy"> Kandy</option>
				   <option value="Matale"> Matale</option>
				   <option value="Nuwara Eliya"> Nuwara Eliya</option>
				   <option value="Galle"> Galle</option>
				   <option value="Matara"> Matara</option>
				   <option value="Hambantota"> Hambantota</option>
				   <option value="Jaffna"> Jaffna</option>
				   <option value="Kilinochchi"> Kilinochchi</option>
				   <option value="Mannar"> Mannar</option>
				   <option value="Vavuniya"> Vavuniya</option>
				   <option value="Mullaitivu"> Mullaitivu</option>
				   <option value="Batticaloa">Batticaloa</option>
				   <option value="Ampara"> Ampara</option>
				   <option value="Trincomalee"> Trincomalee</option>
				   <option value="Kurunegala"> Kurunegala</option>
				   <option value="Puttalam"> Puttalam</option>
				   <option value="Anuradhapura"> Anuradhapura</option>
				   <option value="Polonnaruwa"> Polonnaruwa</option>
				   <option value="Badulla"> Badulla</option>
				   <option value="Moneragala"> Moneragala</option>
				   <option value="Ratnapura"> Ratnapura</option>
				   <option value="Kegalle"> Kegalle</option>
				   </select>
			</div>
				<div class="form-control">
				
				<input type="text" name="address" placeholder="Home No Street Name City," id="address"  onkeydown="checkInput()" required="">
				<i class="icon1 fa-solid fa-circle-check"></i>
				<i class="icon2 fa-solid fa-circle-exclamation"></i>
				<small>Error Message</small>
			</div>
				<div class="form-control">
				<label>User Name</label>
				<input type="text" name="username" placeholder="UserName" id="username"  onkeydown="checkInput()" required="">
				<i class="icon1 fa-solid fa-circle-check"></i>
				<i class="icon2 fa-solid fa-circle-exclamation"></i>
				<small>Error Message</small>
			</div>
		
			<div class="form-control">
				<label>Email</label>
				<input type="text" name="email" placeholder="Email" id="email"  onkeydown="checkInput()" required="">
				<i class="icon1 fa-solid fa-circle-check"></i>
				<i class="icon2 fa-solid fa-circle-exclamation"></i>
				<small>Error Message</small>
			</div>
				<div class="form-control">
				<label>Mobile Number</label>
				<input type="number" name="mobilenumber" placeholder="Mobile Number" id="mobilenumber"  onkeydown="checkInput()" required="">
				<i class="icon1 fa-solid fa-circle-check"></i>
				<i class="icon2 fa-solid fa-circle-exclamation"></i>
				<small>Error Message</small>
			</div>
			<div class="form-control">
				<label>Password</label>
				<input type="Password" name="password" placeholder="Password" id="password"  onkeydown="checkInput()" required="">
				<i class="icon1 fa-solid fa-circle-check"></i>
				<i class="icon2 fa-solid fa-circle-exclamation"></i>
				<small>Error Message</small>
			</div>
			<div class="form-control">
				<label>Confirm Password</label>
				<input type="Password" name="password2" placeholder="Confirm Password" id="password2"  onkeydown="checkInput()" required="">
				<i class="icon1 fa-solid fa-circle-check"></i>
				<i class="icon2 fa-solid fa-circle-exclamation"></i>
				<small>Error Message</small>
			</div>
			
				
				<button type="submit" name="submit">Submit</button>

		</form>
			<p>By clicking the Sign Up button,you agree to our <br><a href="#">Terms and Condition </a>and <a href="#">Policy Privacy</a></p>
	</div>
			<p class="para2">Already have an account?<a href="login.php">Login here</a></p>

<!-- For Script -->
	<script >
		function checkInput(){
			const form=document.getElementById("form"); 
		const fname=document.getElementById("fname"); 
		const lname=document.getElementById("lname"); 
		const district=document.getElementById("district"); 
		const address=document.getElementById("address"); 
		const username=document.getElementById("username"); 
		const email=document.getElementById("email"); 
		const mobilenumber=document.getElementById("mobilenumber");
		const password=document.getElementById("password"); 
		const password2=document.getElementById("password2"); 

			const fnameValue=fname.value.trim();
			const lnameValue=lname.value.trim();
			const addressValue=address.value.trim();
			const usernameValue=username.value.trim();
			const emailValue=email.value.trim();
			const mobilenumberValue=mobilenumber.value.trim();
			const passwordValue=password.value.trim();
			const password2Value=password2.value.trim();

			if(fnameValue === "")
			{
				setError(fname,"First Name cannot be Blank");
				
			}
			else
				setSuccess(fname);

			if(lnameValue === "")
			{
				setError(lname,"Last Name cannot be Blank");
			}
			else
				setSuccess(lname);
			
			if(addressValue === "")
			{
				setError(address,"Address Name cannot be Blank");
				
			}
			else
				setSuccess(address);
				
			
			if(usernameValue === "")
			{
				setError(username,"UserName cannot be Blank");
				
			}
			else
				setSuccess(username);


			if(emailValue === "")
			{
				setError(email,"Email cannot be Blank");
			}

			else if(!isEmail(emailValue)){
				setError(email,"Not a valid Email");
				
			}
			else
			{
				setSuccess(email);
			}
			
			if(mobilenumberValue === "")
			{
				setError(mobilenumber,"Mobile Number Name cannot be Blank");
				
			}
		
			else 
			{
				setSuccess(mobilenumber);	
			}

			if(passwordValue==="")
			{
				setError(password,"password cannot be Blank");
			}
			
			else
			{
				setSuccess(password);
			}
	
		/*	if(password2Value==="")
			{
				setError(password2,"password cannot be Blank");
			}
			else if(password2Value===passwordValue){
				setSuccess(password2);
			}
			else
				
				setError(password2,"password Does Not Match");
			}
*/
}

//For email check function---
			function isEmail(email)
			{
				return /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/.test(email);
			} 


			function setError(input,message)
			{
				const formControl=input.parentElement;
				const small=formControl.querySelector('small');
				formControl.className="form-control error";
				small.innerText=message;
			}
			function setSuccess(input){
				const formControl=input.parentElement;
				formControl.className="form-control success";

			}

	</script>
	
</body>
</html>

