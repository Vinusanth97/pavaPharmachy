<?php 
//This section is logout after customer have login

session_start();
session_destroy();
header("Location:login.php");




?>