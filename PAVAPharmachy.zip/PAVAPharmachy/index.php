<?php 
ini_set('display_errors',0);
//This for the main page of the project

include("config.php");
session_start();
//if the email is not set then go to login page --
	if(!isset($_SESSION['UserName'])){
	header("Location:login.php");
	    session_destroy();
	}
//session_

	if( !empty($_GET['action']))
	{
		
		header("Location:https://projectinweb2022.000webhostapp.com/index.php#medicines");
	}
				
//if(isset($_POST['login_submit'])){

//echo $_SESSION['Email'];
//echo $_SESSION['Name'];
//To add cart
if(isset($_POST['add_cart']))
{
	if(isset($_SESSION['shopping_cart']))
	{	
		$session_array_id=array_column($_SESSION['shopping_cart'], 'id');
	if(!in_array($_POST['id'], $session_array_id)){
$session_array=array(
			'id'=>$_POST['id'],
			'name'=>$_POST['hidden_name'],
			'price'=>$_POST['hidden_price'],
			'quantity'=>$_POST['quantity']
		 );
			
			$_SESSION['shopping_cart'][]=$session_array;
	}
	}
		else
		{
			$session_array=array(
			'id'=>$_POST['id'],
			'name'=>$_POST['hidden_name'],
			'price'=>$_POST['hidden_price'],
			'quantity'=>$_POST['quantity']
		 );
			
			$_SESSION['shopping_cart'][]=$session_array;
		}
 }

		if(isset($_POST["contact_message"]))
				{
				
				 	$username = mysqli_real_escape_string($link,$_SESSION['UserName']);
				 	$email = mysqli_real_escape_string($link, $_POST['email']);
					$message = mysqli_real_escape_string($link, $_POST['message']);
      
					mysqli_query($link, "INSERT INTO contact_message(username,email, message) VALUES('$username','$email','$message')");
                    //$message[] = 'registered successfully!';
						}
							
					
							

?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Pharmachy Application</title>
	<!-- font awesome-->
	<script src="https://kit.fontawesome.com/228b3df31e.js" crossorigin="anonymous"></script>
	<!-- This for css file link-->
	<link rel="stylesheet" href="style20.css">

	<!-- this for bootrap css link -->
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
</head>

<body>
	<!-- this for bootrap js code link -->
	<script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js" ></script>
	<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.min.js"></script>

	<!-- Navabar-->
	<nav class="navbar navbar-expand-lg navbar-dark" id="navbar">
		<dic class="container">
  			<a class="navbar-brand" href="#about"><img src="images/logo1.png" width="60px" height="50px" class="img-fluid">PAVA PHARMACHY</a>
  			<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-expanded="false">
    		<span class="navbar-toggler-icon"></span>
  			</button>

 				<div class="collapse navbar-collapse" id="navbarSupportedContent">
						<ul class="navbar-nav mx-auto">
     					 <li class="nav-item">
        					<a class="nav-link" href="#home">Home</a></li>
     					 
 							<li class="nav-item">
        					<a class="nav-link" href="#about">About</a> </li>
     				 
              <li class="nav-item">
                  <a class="nav-link" href="#medicines">Medicines</a></li>
     					 
       				<li class="nav-item">
        					<a class="nav-link" href="#contact">Contact</a></li>
      
				    </ul> 
				      <a href="logout.php"   class="logout">
				    <button class="logout btn p-2 my-lg-0 my-2">Logout</button>  </a>

				    <a href="signUp.php"  class="signUp">
				    <button class="signUp btn p-2 my-lg-0 my-2">Sign Up</button>  </a>
				</div>
		</nav>

		<!-- Home-->
	 	<section id="home">
	 		<h1 class="text-center">MEDICINE DELIVERY</h1>
	 		<p>Nature food is the powerhouse of good health</p>
	 	<!--
	 		<div class="input-group m-4">
	 			<input type="text" class="form-control" placeholder="Email Address">
	 			<a href="login.html" target="_blank">
	 			<button class="btn signin">Get Started</button></a>
	 		</div>
	 		-->
	 		<?php
	 		
	 		echo "<b>Welcome ".$_SESSION['UserName']."</b>";
	 		
	 	
	 		?>
 		</section>

 <!---About -->
 	<section id= "about">

 		<div class="container-fluit">
 				<div class="row">
 				<div class="col-lg-6 col-md-6 col-12 p-lg-5 my-5">
 					<img src="images/logo1.png" width="300px" height="300px"  class="img-fluid">
 				</div>
 				<div class="col-lg-6 col-md-6 col-12 p-lg-4 p-2 my-5">
 					<h1 >ABOUT US</h1>
 					<input type="checkbox" id="check">
 					<p>Our website name is PAVA pharmacy medicine delivery. This website designed to delivery medical 
					products to customer.
					Currently the situation in our country Sri Lanka is very bad as it is in the middle of economic crisis, effect 
					transportation so it is very difficult for many customers to buy medicines from the hospital
					and we delivery our medicines nationwide.We have been successfully running our pharmacy in Srilanka for the past five years.We are working to develop our hospital in the future.</p>

					<div class="para_2">
					Why use it?<br>
					*Providing complete service to customers at low cost.<br>
					*Reducing the transportation cost of the customers and reducing the waiting time.<br>
					*It will be a path of process for our country to become like developed countries.<br>
					*The products will be delivered to customer home.<br>
					*We will always be reliable to people.<br>
					*We are ready to serve people round the clock.
				</p></div>
								<label for="check">Read More</label>
					
			 
 			</div>
 		</div>
	</section>

	<!--This for medicines-->
	</div>
	
	
	<section id="medicines">
		<div class="container-fluit">
		    <!-- First column start -->
				<h1 class="text-center my-5">MEDICINES</h1>
		
		<div class="row">
			<div class="col-sm-7">
				
						<div class="input-group m-4">	
							<form action="index.php#medicines" method="GET">
							   
							    <input type="file" name="photo">
								<input type="text" class="form-control" placeholder="Search items" name="SEARCH" value="<?php if(isset($_GET['SEARCH'])){echo $_GET['SEARCH'];}?>">
								<button type="submit" class="btn btn-primary" style="display:inline">SEARCH</button>
								
							</form>
						
						</div><br><br>

						<div class="row">
					<?php 
				//To find search medicines items
				if(isset($_GET['SEARCH']))
				{
					if(!empty($_GET['SEARCH'])){
					$search=$_GET['SEARCH'];
						$form_query="Select* from medicines where name like '%$search%'";
							$query_run=mysqli_query($link,$form_query);
								if(mysqli_num_rows($query_run)>0)
								{
									while($row_medicines=mysqli_fetch_assoc($query_run))
									{
									//	echo "Hi this id is every one see no pleze".$row_medicines['id'];
										?>
						<div class="col-lg-4 col-md-5 col-12">
						<div class="card" id="search_card">

							<form action="index.php?action='add'&id='<?php echo $row_medicines['id']; ?>" method="post">

								<p align="center"><img src="<?php echo $row_medicines['picture_path']; ?>" class="card-img-top"></p>
								<div class="card-body text-center">

									<h5 class="card-title"><?php echo $row_medicines['name'];?></h5>
									<p>Price :<?php echo number_format($row_medicines['price'],2);?></p>

									<input type="hidden" name="id" value="<?php echo $row_medicines['id'];?>">
									<input type="hidden" name="hidden_name" value= "<?php echo $row_medicines['name'];?>" >
									<input type="hidden" name="hidden_price" value="<?php echo $row_medicines['price'];?>" >
									<input type="hidden" name="quantity" value=1 calss='quantity_input'>
									
								<!-- 	<input type="submit" class="btn btn-primary" value="BUY" onclick="order_recieved()">
								-->
									<input type="submit" class="btn btn-primary" style="background-color:#D5CD2A;color:black;" value="Add To Card" name="add_cart">
							
							</form>
							</form>
								<form action="index.php?action='buy'" method="POST">
								     <input type="hidden" name="hidden_name" value= "<?php echo $row_medicines['name'];?>">
									<input type="hidden" name="hidden_price" value= "<?php echo $row_medicines['price'];?>">
									<input type="number" name="quantity"  class='quantity_input' placeholder="QUANTITY">
								 <input type="submit" class="btn btn-primary" value="BUY" name="BUY">
								 </form>	</div>
                            
								
						</div>
						</div>

										<?php
									}

								}
								else{echo "No Items Found!!";}
					}
					}
					
			
		
				$query="select* from medicines";
				$result=mysqli_query($link,$query);
				/* to form*/
				if(mysqli_num_rows($result)>0)
					{
						while($row=mysqli_fetch_assoc($result))
						{?>

							<div class="col-lg-4 col-md-5 col-sm-12">
							<div class="card">
								<form action="index.php?action='add'&id='<?php echo $row['id']; ?>'" method="post" name="f1">
								<p align="center"><img src="<?php echo $row['picture_path'] ?>" class="card-img-top"></p>
								<div class="card-body text-center">
									<h5 class="card-title"><?php echo $row['name'];?></h5>
									<p>Price :<?php echo number_format($row['price'],2);?></p>
									
									<input type="hidden" name="id" value="<?php echo $row['id'];?>">
									<input type="hidden" name="hidden_name" value= "<?php echo $row['name'];?>">
									<input type="hidden" name="hidden_price" value= "<?php echo $row['price'];?>">
									<input type="hidden" name="quantity" value="1" class='quantity_input'>
									
							
									<input type="submit" class="btn btn-primary" style="background-color:#D5CD2A;color:black;" value="Add Cart" name="add_cart">
										
									
								</form>
								<form action="index.php?action='buy'" method="POST">
								    <input type="hidden" name="hidden_name" value= "<?php echo $row['name'];?>">
									<input type="hidden" name="hidden_price" value= "<?php echo $row['price'];?>">
									<input type="number" name="quantity"  class='quantity_input' placeholder="QUANTITY">
									
								 <input type="submit" class="btn btn-primary" name="BUY" value="BUY">
								 </form></div>
								
								
								</div>
									</div>
				 <?php }} ?>		
						
				</div>
     

<!-- First column end -->
			</div>


			<div class="col-sm-5" align="center">
				<!-- Second column start-->
       <?php  
     /* 
       	if(isset($_GET['action']))
					{
						//echo "2232222222222222222222222222222Hi12";
						if($_GET['action']=='buy')
						{
						    //echo "ok";
						    $array();
						if(!empty($_SESSION['shopping_cart']))
						{
						
							foreach ($_SESSION['shopping_cart'] as $key => $value) {
							    
						     $array= $value['name'];
									
							 echo $value['quantity'];
						    
						    }
				    	}
						$sql="insert into customers_orders(username,medicines_name,quantities) values();"
						    
						}
					}
       */
      ?>
      
      
      
      
      
      
      
      
      
      
      
      
			
						<h6>Your Cart<i class="fa-solid fa-cart-plus"></i></h6>
						
						<table>
						<tr>
						<th>ID</th>
						<th>Name</th>
						<th>Price</th>
						<th>Quantity</th>
						<th>Total Price</th>
						<th>Action</th>
						</tr>
					<?php 
					
						if(!empty($_SESSION['shopping_cart']))
						{
							$total=0;
							foreach ($_SESSION['shopping_cart'] as $key => $value) {
								$total=$total+$value['price']*$value['quantity'];
								?>
								<tr>
									<td><?php echo $value['id'];?></td>
									<td><?php echo $value['name'];?></td>
									<td><?php echo "Rs.".number_format($value['price'],2);?></td>
									<td><?php echo $value['quantity'];?></td>
									<td><?php echo "Rs.".number_format(($value['price']*$value['quantity']),2);?></td>
									<td><a href="index.php?action=remove&id=<?php echo $value['id']?>">
										<button style="background-color:#14950E;color:black; border: none;margin: 2px;border-radius: 3px;">Remove</button></a></td>
								</tr>
									
						<?php	}?>
								<tr>
									<td colspan="3"><a href="index.php?action=buy">
										<button class="btn btn-primary" name="buy">BUY</button></a></td>
									<td style="color: red;">Total Price</td>
									<td><?php echo "RS.".number_format($total,2)?></td>
									<td><a href="index.php?action=clearAll">
										<button style="background-color:#950E29;color:white; border: none;margin: 2px;border-radius: 3px">Clear All</button></a>
									</td>
								</tr>


					<?php 	}?>



					</table>
					<?php 
					if(isset($_GET['action']))
					{
						//echo "2232222222222222222222222222222Hi12";
						if($_GET['action']=='remove')
						{
							//echo "4444444444444444444444444444444444444444444Hi123";
							foreach ($_SESSION['shopping_cart'] as $key => $value) {

								if($value['id']==$_GET['id'])
								{
									unset($_SESSION['shopping_cart'][$key]);
								}
							}

						}
							if($_GET['action']=='clearAll')
						{
							unset($_SESSION['shopping_cart']);
						}
						
						
					}
					if(isset($_POST['BUY']))
					{
					    $username = mysqli_real_escape_string($link,$_SESSION['UserName']);
				           $medicines_name = mysqli_real_escape_string($link, $_POST['hidden_name']);
					       $quantities = mysqli_real_escape_string($link, $_POST['quantity']);
      
						  //echo $username;
						 // $sql="insert into customers_orders(username,medicines_name,quantities) values( $_SESSION['UserName'],$medicines_name,$quantities")";
						 	mysqli_query($link, "INSERT into customers_orders(username,medicines_name,quantities) VALUES('$username','$medicines_name',$quantities)");
                  
					}

					?>
				
					


	
	
						

<!-- second column end -->
			</div>


</div>
</div>

	</section>

	<!-- Conduct -->
	 	<section id="contact">
	 			<div class="container-fluit">
	 				<div class="row">
	 					<div class="col-lg-6 col-md-6 col-12">
	 							<img src="images/contact1.jpg" width="80%" height="350px">
	 							
	 							<p class="para3">
	 							<i class="fa-solid fa-location-dot"></i> KKS Road,Jaffna,Srilanka.<br>
	 							 
	 							<i class="fa-brands fa-twitter"></i>@PavaPharmachy<br>
	 							<i class="fa-brands fa-facebook"></i> PavaPharmachy20@gmail.com<br>
	 							<i class="fa-regular fa-circle-user"></i> +94 000000000</p>
	 						
	 					</div>
						
							
						
						
					
						
						
						<div class="col-lg-6 col-md-6 col-12">
	 							<h1>CONTACT US</h1>
	 							<form action="index.php#contact" method="post">
	 								<input type="text" class="form-control" placeholder="<?php echo $_SESSION['UserName'];?>">
	 								<input type="text" class="form-control" placeholder="Enter Your Email"
                                	name="email">
	 								<textarea  class="form-control" placeholder="Enter Your Message" name="message"></textarea>
	 								<button class="btn signin" name="contact_message">Send Message</button>
	 							</form><br><br>
	 								<h4>Payment Option</h4>
	 								<!--
									<img src="images/card.webp" width="120px" height="120px" alt="credit card">
									<img src="images/paypal.webp" width="120px" height="120px" alt="paypal transfer">
									-->
									<img src="images/cash.webp" width="120px" height="120px" alt="cash on delivery"><br>
									
									<p><b><!-- #Debit cards <span style="padding-left:20px;">#Paypal<span style="padding-left:50px;">
									-->#Cash on delivery</b></p>
						</div>
					</div>
	 		  </div>
	 	</section>
 </body>			
<footer>
	<p>© 2022 PAVA medicines.com. All Rights Reserved.</p>
</footer>


</html>