<?php
//This for the config file to use php file session variable....

try{
    $link=mysqli_connect('localhost','id19376103_root','dhjlEu3WR?sz!t85','id19376103_webtech');
}
catch(Exception $ex)
{
    echo 'DB Connecton Error.'.mysqli_connect_error();
}
?>