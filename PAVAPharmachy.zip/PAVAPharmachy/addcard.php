<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
	<!-- Bootrap -->
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
</head>
<body>

</body>
</html>




<?php 
						if(isset($_POST['add_cart']))
							{
								if(isset($_SESSION['card']))
									{	
										$_session_array_id=array_column($_SESSION['cart'], 'id');
										if(!in_array($_POST['id'], $_session_array_id))
											{
												$session_array=array(
												'id'=>$_POST['id'],
												'name'=>$_POST['hidden_price'],
												'price'=>$_POST['hidden_price'],
												'quantity'=>$_POST['quantity']
												 );
												$_SESSION['cart'][]=$session_array;
											}	
									}
								else
								{
									$session_array=array(
								'id'=>$_POST['id'],
								'name'=>$_POST['hidden_name'],
								'price'=>$_POST['hidden_price'],
								'quantity'=>$_POST['quantity']
								 );
								}
								$_SESSION['cart'][]=$session_array;
							}
							?>

		

		<h6>Your Cart<i class="fa-solid fa-cart-plus"></i></h8></a>
		<a href="index1.php#medicines"><h6>Back</h6></a>

<div class="add_cart">


<?php 
$output="";
$output.="
<table class='table table-bordered table-striped'>
<tr>
	<th>ID</th>
	<th>Item Name</th>
	<th>Item Price</th>
	<th>Quantity</th>
	<th>Total Price</th>
	<th>Action</th>
	<tr>
	";

	if(!empty($_SESSION['cart'])){
	foreach($_SESSION['cart']as $key=>$value)
	{
		$output.="
		
	<td>".$value['id']."</td>
	<td>".$value['name']."</td>
	<td>".$value['price']."</td>
	<td>".$value['quantity']."</td>
	<td>Rs.".number_format($value['price']*$value['quantity'],2)."</td>
	<td><a href='addcard.php?action=remove & id=".$value['id'].">
			<button>Remove</button></a>
	</td>
		";
		echo $output;
	}
}


?>







