<?php
ob_start();
//This for the login part of the index.php
 include("config.php");
session_start();
?>

<!DOCTYPE html>
<html>
<head>
	
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="signUp_login_Style.css">
	<title>Login Page</title>
</head>
<body>
		<div class="login-box">
		<h1>Login</h1>
			<form class="form"  method="POST">
			    <label>User Name</label>
				<input type="text" placeholder="User Name" name="login_username" required="">
				<!-- For hidden field to email
				<input type="hidden" placeholder="Email" name="login_email" required="">
				-->
				<label>Password</label>
				<input type="Password" placeholder="Password" name="login_password" required="">
				<button name="login_submit">submit</button>
			</form>
	</div>
			<p class="para2">Not have an account? <a href="signUp.php">Sign UP here</a></p>	
</body>
</html>
<?php 
//echo "Vinu";
$link=mysqli_connect('localhost','id19376103_root','dhjlEu3WR?sz!t85','id19376103_webtech');


if($link->connect_errno)
{
	echo $link->connect_error;
	die();
}
else
{
	//echo "Database connected";
}
if(isset($_POST['login_submit'])){
	//echo "hi";
	$username_L=$_POST['login_username'];
//	$email_L=$_POST['login_email'];
	$password_L=$_POST['login_password'];
		$sql="SELECT username,password from customers where username='$username_L' and password='$password_L'";
	$result=mysqli_query($link,$sql);
	$count=mysqli_num_rows($result);
	if($count>0)
	{

		 //$_SESSION['First_Name']=$fname;
		$_SESSION['UserName']=$username_L;
		

		//$_SESSION['Name']=fname;
		header("Location:index.php");
		ob_enf_flush();
		
	}
	else
	{
		echo "<div class='conformationerror'>Invalid User Name and PassWord</div>";
	}
		
	}				
					
					
		//echo "HI";			


?>